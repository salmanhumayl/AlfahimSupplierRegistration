﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Dapper;
using System.Configuration;
using System.Data;
using AlfahimSupplierRegistration.ViewModels;
using System.Data.SqlClient;

namespace AlfahimSupplierRegistration.Controllers
{
    public class AdminController : Controller
    {
        private IDbConnection db;
        // GET: Admin
        [Authorize(Users = "waseem.anwar@alfahim.ae")]
        public ActionResult Index()
        {

            db = new SqlConnection(ConfigurationManager.ConnectionStrings["cn"].ConnectionString);
            var obj = db.Query<Models.Supplier>("Select * from tblSupplier").ToList();
            db.Close();

            return View(obj);
        }

        public string Test()
        {
            string SendEmailToSupplierSubject=ConfigurationManager.AppSettings["SendEmailToSupplierSubject"].ToString();
            string SendEmailToSupplierBody = ConfigurationManager.AppSettings["SendEmailToSupplierBody"].ToString();

            return SendEmailToSupplierBody;
        }
    }
}