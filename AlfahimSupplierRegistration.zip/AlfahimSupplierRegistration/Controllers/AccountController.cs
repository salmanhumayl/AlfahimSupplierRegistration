﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Dapper;
using System.Data.SqlClient;
using System.Data;
using System.Web.Security;

namespace AlfahimSupplierRegistration.Controllers
{
    public class AccountController : Controller
    {
        private IDbConnection db;

        // GET: Account
        public ActionResult Registration(string email, string Password)
        {

            string ErrorMsg= "Success";
            db = new SqlConnection(ConfigurationManager.ConnectionStrings["cn"].ConnectionString);



            string sql = " INSERT INTO tblUsers(UserName,Password) " +
                             " VALUES (@email,@Password)";

            try
            { 
            db.Execute(sql, new
            {
                email,
                Password
               
            });
            }
            catch (Exception e)
            {
                if (e.Message.IndexOf("Email-Already-Exist") > 0)
                {

                    ErrorMsg = "Email Address Already Exist....";
                }
                else
                { 
                ErrorMsg= e.Message;
                }
                db.Close();
            }
 
            return new JsonResult
            {
                Data = ErrorMsg,
                JsonRequestBehavior = JsonRequestBehavior.AllowGet
            };
        }


        public JsonResult LoginIn(string email, string Password)
        {

            string ErrorMsg = "false";
            int UserId = 0;
            db = new SqlConnection(ConfigurationManager.ConnectionStrings["cn"].ConnectionString);

            string sql = " Select ID from tblUsers Where UserName ='" + email + "' And Password='" + Password + "' ";

            try
            {
                var obj = db.Query(sql).ToArray();
                if (obj.Length > 0)
                {
                    ErrorMsg ="true";
                    UserId = obj[0].ID;
                    FormsAuthentication.SetAuthCookie(email,false);

                    if (Request.IsAuthenticated)
                    {

                    }
                    else
                    {


                    }
                }
         
            }
            catch (Exception e)
            {
                ErrorMsg = e.Message;
                db.Close();
            }




            var Data = new { Message = ErrorMsg, UserID = UserId };
            return Json(Data, JsonRequestBehavior.AllowGet);
        
        }

    }
}